public interface IBook {
    String entry();
    String print();
}
